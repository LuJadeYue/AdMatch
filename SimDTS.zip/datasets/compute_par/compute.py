# import os
# import cv2
# import numpy as np
# from PIL.Image import Image
#
# path = 'D:\\Jupyterfile\\LJY\\data\\AID\\AID'  # 图片保存路径
# dir__name= 'D:\\Jupyterfile\\LJY\\data\\AID\\AID'  # 图片保存路径
#
# def compute(path):
#     file_names = os.listdir(path)
#     print(file_names)
#     per_image_Rmean = []
#     per_image_Gmean = []
#     per_image_Bmean = []
#
#     g = os.walk(dir__name)
#     for path, dir_list, file_list in g:
#         for file_name in file_list:
#             full_path = os.path.join(path, file_name)
#             img = cv2.imread(full_path)
#             per_image_Bmean.append(np.mean(img[:, :, 0]))
#             per_image_Gmean.append(np.mean(img[:, :, 1]))
#             per_image_Rmean.append(np.mean(img[:, :, 2]))
#
#     R_mean = np.mean(per_image_Rmean)
#     G_mean = np.mean(per_image_Gmean)
#     B_mean = np.mean(per_image_Bmean)
#     stdR = np.std(per_image_Rmean)
#     stdG = np.std(per_image_Gmean)
#     stdB = np.std(per_image_Bmean)
#     return R_mean, G_mean, B_mean, stdR, stdG, stdB
#
#
# if __name__ == '__main__':
#     stdR, stdG, stdB, B_mean, R_mean, Gmean = compute(path)
#     print("R_mean= ", R_mean, "G_mean= ", Gmean, "B_mean=", B_mean, "stdR = ", stdR, "stdG = ", stdG, "stdB =", stdB)
#

import torch
import torchvision
from torchvision.datasets import ImageFolder
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


def getStat(train_data):
    '''
    Compute mean and variance for training data
    :param train_data: 自定义类Dataset(或ImageFolder即可)
    :return: (mean, std)
    '''
    print('Compute mean and variance for training data.')
    print(len(train_data))
    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=1, shuffle=False, num_workers=0,
        pin_memory=True)
    mean = torch.zeros(3)
    std = torch.zeros(3)
    for X, _ in train_loader:
        for d in range(3):
            mean[d] += X[:, d, :, :].mean()
            std[d] += X[:, d, :, :].std()
    mean.div_(len(train_data))
    std.div_(len(train_data))
    return list(mean.numpy()), list(std.numpy())


if __name__ == '__main__':

    str = input('which dataset you want to compute?\n')
    if str == 'pat':
        train_data = 'D:\\Jupyterfile\\LJY\\data\\PatternNet'
    elif str == 'RSSCN7':
        train_data = 'D:\\Jupyterfile\\LJY\\data\\RSSCN7'
    elif str == 'siri':
        train_data = 'D:\\Jupyterfile\\LJY\\data\\SIRI-WHU\\12class_tif'
    elif str == 'whu':
        train_data = 'D:\\Jupyterfile\\LJY\\data\\WHU-RS19'

    train_dataset = ImageFolder(root=train_data, transform=torchvision.transforms.ToTensor())
    print(getStat(train_dataset))
